// import React from 'react';
// import { Outlet } from 'react-router-dom';
// // import SideBar from './SideBar';
// // import UploadBook from './UploadBook';


// const DashboardLayOut = ({children}) => {
//   return (
//     <div className="flex">
//     {/* Fixed Sidebar */}
//     {/* <SideBar /> */}

//     {/* Main Content */}
//     <div className="flex-1 ml-[250px] p-4">
//       <Outlet />
//       {children}
//     </div>
//   </div>
//   )
// }

// export default DashboardLayOut;