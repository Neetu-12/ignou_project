import React from 'react';
import SingleBook from '../../shop/SingleBook';

const BookDetails = () => {
    
  return (
    <div>
        <SingleBook/>
    </div>
  )
}

export default BookDetails;