// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyB_uiV9bTrJ9eJaHQoYIoCfQ4dBPyyFOEY",
  authDomain: "mern-book-inventory-bd4ba.firebaseapp.com",
  projectId: "mern-book-inventory-bd4ba",
  storageBucket: "mern-book-inventory-bd4ba.firebasestorage.app",
  messagingSenderId: "618467858752",
  appId: "1:618467858752:web:c5088f3870c10c912642a5"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

export default app;