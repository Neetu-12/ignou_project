import React from 'react';
// import { BrowserRouter as Router, Route, Routes } ffrom "react-router-dom";

// import Home from "../home/Home";
// import App from "../App";
// import Shop from "../shop/Shop";
// import Navbar from "../navbar/Navbar";
// import Footer from "../footer/Footer";

const router = () => {
  return (
    <>
      {/* {<div>
        <Router>
          <Navbar />
          <Routes>
            <Route path="/" exact Component={App} />
            <Route path="/" exact Component={Home} />
            <Route path="/shop" exact Component={Shop} />
          </Routes>
          <Footer />
        </Router>
      </div>} */}
    </>
  )
}

// const router = createBrowserRouter([


//   // {
//   //   path: "/",
//   //   element: <App />,
//   //   children: [
//   //     {
//   //       path: '/',
//   //       element: <Home />
//   //     }, 
//   //     {
//   //       path:'/shop',
//   //       element:<Shop/>
//   //     }
//   //   ]
//   // },
// ]);

export default router;